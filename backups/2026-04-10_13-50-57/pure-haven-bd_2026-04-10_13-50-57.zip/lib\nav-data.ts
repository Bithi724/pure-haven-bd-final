export type NavChild = {
  label: string;
  href: string;
};

export type NavSection = {
  title: string;
  children: NavChild[];
};

export type NavItem = {
  label: string;
  href: string;
  sections?: NavSection[];
};

export const navItems: NavItem[] = [
  {
    label: "Home",
    href: "/",
  },
  {
    label: "Makeup Shop",
    href: "/shop?category=cosmetics",
    sections: [
      {
        title: "Lip Makeup",
        children: [
          { label: "Lipstick", href: "/shop?category=cosmetics&subcategory=lipstick" },
          { label: "Liquid Lipstick", href: "/shop?category=cosmetics&subcategory=liquid-lipstick" },
          { label: "Lip Liner", href: "/shop?category=cosmetics&subcategory=lip-liner" },
          { label: "Lip Gloss", href: "/shop?category=cosmetics&subcategory=lip-gloss" },
          { label: "Lip Balm", href: "/shop?category=cosmetics&subcategory=lip-balm" },
        ],
      },
      {
        title: "Face Makeup",
        children: [
          { label: "Foundation", href: "/shop?category=cosmetics&subcategory=foundation" },
          { label: "Face Powder", href: "/shop?category=cosmetics&subcategory=face-powder" },
          { label: "Primer", href: "/shop?category=cosmetics&subcategory=primer" },
          { label: "Concealer", href: "/shop?category=cosmetics&subcategory=concealer" },
          { label: "Blush", href: "/shop?category=cosmetics&subcategory=blush" },
          { label: "Highlighter", href: "/shop?category=cosmetics&subcategory=highlighter" },
        ],
      },
      {
        title: "Eye Makeup",
        children: [
          { label: "Eyeliner", href: "/shop?category=cosmetics&subcategory=eyeliner" },
          { label: "Kajal", href: "/shop?category=cosmetics&subcategory=kajal" },
          { label: "Mascara", href: "/shop?category=cosmetics&subcategory=mascara" },
          { label: "Eyeshadow", href: "/shop?category=cosmetics&subcategory=eyeshadow" },
          { label: "Eyebrow Pencil", href: "/shop?category=cosmetics&subcategory=eyebrow-pencil" },
        ],
      },
      {
        title: "Tools",
        children: [
          { label: "Brush", href: "/shop?category=cosmetics&subcategory=brush" },
          { label: "Sponge", href: "/shop?category=cosmetics&subcategory=sponge" },
          { label: "Makeup Remover", href: "/shop?category=cosmetics&subcategory=makeup-remover" },
        ],
      },
    ],
  },
  {
    label: "Hair Care Shop",
    href: "/shop?category=haircare",
    sections: [
      {
        title: "Hair Care",
        children: [
          { label: "Shampoo", href: "/shop?category=haircare&subcategory=shampoo" },
          { label: "Conditioner", href: "/shop?category=haircare&subcategory=conditioner" },
          { label: "Hair Oil", href: "/shop?category=haircare&subcategory=hair-oil" },
          { label: "Hair Serum", href: "/shop?category=haircare&subcategory=hair-serum" },
          { label: "Hair Mask", href: "/shop?category=haircare&subcategory=hair-mask" },
          { label: "Hair Color", href: "/shop?category=haircare&subcategory=hair-color" },
          { label: "Hair Treatment", href: "/shop?category=haircare&subcategory=hair-treatment" },
          { label: "Styling Gel & Spray", href: "/shop?category=haircare&subcategory=styling-gel-spray" },
        ],
      },
    ],
  },
  {
  label: "Skincare",
  href: "/shop?category=skincare",
  sections: [
    {
      title: "Skin Care",
      children: [
        { label: "Face Wash", href: "/shop?category=skincare&subcategory=face-wash" },
        { label: "Moisturizer", href: "/shop?category=skincare&subcategory=moisturizer" },
        { label: "Lotion", href: "/shop?category=skincare&subcategory=lotion" },
        { label: "Serum", href: "/shop?category=skincare&subcategory=serum" },
        { label: "Sunscreen", href: "/shop?category=skincare&subcategory=sunscreen" },
        { label: "Toner", href: "/shop?category=skincare&subcategory=toner" },
        { label: "Scrub", href: "/shop?category=skincare&subcategory=scrub" },
        { label: "Face Mask", href: "/shop?category=skincare&subcategory=face-mask" },
        { label: "Petroleum Jelly", href: "/shop?category=skincare&subcategory=petroleum-jelly" },
      ],
    },
  ],
},
{
  label: "Perfume Shop",
  href: "/shop?category=perfume",
  sections: [
    {
      title: "For Men",
      children: [
        { label: "EDT", href: "/shop?category=perfume&subcategory=edt-men" },
        { label: "EDP", href: "/shop?category=perfume&subcategory=edp-men" },
        { label: "Perfume", href: "/shop?category=perfume&subcategory=perfume-men" },
      ],
    },
    {
      title: "For Women",
      children: [
        { label: "EDT", href: "/shop?category=perfume&subcategory=edt-women" },
        { label: "EDP", href: "/shop?category=perfume&subcategory=edp-women" },
        { label: "Perfume", href: "/shop?category=perfume&subcategory=perfume-women" },
      ],
    },
    {
      title: "More",
      children: [
        { label: "Attar", href: "/shop?category=perfume&subcategory=attar" },
        { label: "Air Freshener", href: "/shop?category=perfume&subcategory=air-freshener" },
      ],
    },
  ],
},
  {
    label: "Food",
    href: "/shop?category=food",
    sections: [
      {
        title: "Food Items",
        children: [
          { label: "Honey", href: "/shop?category=food&subcategory=honey" },
          { label: "Tea", href: "/shop?category=food&subcategory=tea" },
          { label: "Coffee", href: "/shop?category=food&subcategory=coffee" },
          { label: "Snacks", href: "/shop?category=food&subcategory=snacks" },
          { label: "Organic Food", href: "/shop?category=food&subcategory=organic-food" },
          { label: "Health Drinks", href: "/shop?category=food&subcategory=health-drinks" },
        ],
      },
    ],
  },
  {
    label: "Men’s Products",
    href: "/shop?category=mens-products",
    sections: [
      {
        title: "Men's Care",
        children: [
          { label: "Face Wash", href: "/shop?category=mens-products&subcategory=face-wash" },
          { label: "Beard Oil", href: "/shop?category=mens-products&subcategory=beard-oil" },
          { label: "Shaving Cream", href: "/shop?category=mens-products&subcategory=shaving-cream" },
          { label: "After Shave", href: "/shop?category=mens-products&subcategory=after-shave" },
          { label: "Deodorant", href: "/shop?category=mens-products&subcategory=deodorant" },
          { label: "Body Spray", href: "/shop?category=mens-products&subcategory=body-spray" },
          { label: "Grooming Kit", href: "/shop?category=mens-products&subcategory=grooming-kit" },
        ],
      },
    ],
  },
];