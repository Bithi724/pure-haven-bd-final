export default function TopBar() {
  return (
    <div className="border-b border-[#ead9d1] bg-[#f8f3ef] text-sm">
      <div className="container-ph flex flex-col gap-2 py-2 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap items-center gap-4">
          <span>+880 1234 567 890</span>
          <span>support@purehavenbd.com</span>
        </div>

        <div className="text-center font-medium">
          Free Shipping on Orders Over 2000 BDT
        </div>

        <div className="hidden md:block">BDT</div>
      </div>
    </div>
  );
}