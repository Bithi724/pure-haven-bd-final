import Link from "next/link";

type CategoryCardProps = {
  title: string;
  image: string;
  href: string;
};

export default function CategoryCard({
  title,
  image,
  href,
}: CategoryCardProps) {
  return (
    <Link
      href={href}
      className="group relative block overflow-hidden rounded-[24px] border border-[#ead9d1]"
    >
      <div
        className="h-52 bg-cover bg-center transition duration-300 group-hover:scale-105"
        style={{ backgroundImage: `url('${image}')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-black/10 to-transparent" />
      <div className="absolute bottom-4 left-4 text-white">
        <h3 className="text-2xl font-semibold">{title}</h3>
        <p className="mt-1 text-sm">Shop Now</p>
      </div>
    </Link>
  );
}