import Link from "next/link";

export default function Hero() {
  return (
    <section className="section-gap">
      <div className="container-ph grid items-center gap-10 md:grid-cols-2">
        <div className="order-2 md:order-1">
          <p className="mb-3 text-sm uppercase tracking-widest text-[#7a5244]">
            Pure Beauty Collection
          </p>

          <h1 className="text-4xl font-semibold leading-tight md:text-5xl lg:text-6xl">
            Discover Your Natural Glow
          </h1>

          <p className="mt-5 max-w-md text-neutral-600">
            Cosmetics, skincare, perfumes and daily essentials curated for your
            lifestyle.
          </p>

          <div className="mt-6 flex flex-wrap gap-4">
            <Link href="/shop" className="btn-primary">
              Shop Now
            </Link>

            <Link
              href="/shop"
              className="rounded-full border border-[#ead9d1] px-6 py-3 text-[#2e221d] transition hover:bg-[#f8f3ef]"
            >
              Explore
            </Link>
          </div>
        </div>

        <div className="order-1 relative md:order-2">
          <img
            src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop"
            alt="Pure Haven BD hero"
            className="h-[280px] w-full rounded-[32px] object-cover sm:h-[360px] md:h-[420px]"
          />
        </div>
      </div>
    </section>
  );
}