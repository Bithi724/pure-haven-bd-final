import CategoryCard from "@/components/ui/CategoryCard";
import { categories } from "@/lib/data";

export default function CategorySection() {
  return (
    <section className="container-ph section-gap">
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5">
        {categories.map((category) => (
          <CategoryCard
            key={category.title}
            title={category.title}
            image={category.image}
            href={category.href}
          />
        ))}
      </div>
    </section>
  );
}