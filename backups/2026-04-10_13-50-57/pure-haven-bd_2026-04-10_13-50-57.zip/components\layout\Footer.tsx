export default function Footer() {
  return (
    <footer className="mt-10 border-t border-[#ead9d1] bg-white">
      <div className="container-ph grid gap-8 py-12 md:grid-cols-4">
        <div>
          <h3 className="text-2xl font-semibold">Pure Haven BD</h3>
          <p className="mt-3 text-sm text-neutral-600">
            Beauty, care, fragrance and essentials in one clean online store.
          </p>
        </div>

        <div>
          <h4 className="font-semibold">Shop</h4>
          <ul className="mt-3 space-y-2 text-sm text-neutral-600">
            <li>Cosmetics</li>
            <li>Skincare</li>
            <li>Perfumes</li>
            <li>Body Care</li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold">Support</h4>
          <ul className="mt-3 space-y-2 text-sm text-neutral-600">
            <li>Contact Us</li>
            <li>Order Tracking</li>
            <li>Privacy Policy</li>
            <li>Terms &amp; Conditions</li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold">Contact</h4>
          <ul className="mt-3 space-y-2 text-sm text-neutral-600">
            <li>support@purehavenbd.com</li>
            <li>+880 1234 567 890</li>
            <li>Dhaka, Bangladesh</li>
          </ul>
        </div>
      </div>
    </footer>
  );
}