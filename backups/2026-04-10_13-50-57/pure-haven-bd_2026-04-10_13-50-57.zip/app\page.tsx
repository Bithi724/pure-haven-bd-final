import TopBar from "@/components/layout/TopBar";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/home/Hero";
import CategorySection from "@/components/home/CategorySection";
import ProductSection from "@/components/home/ProductSection";
import DealsBanner from "@/components/home/DealsBanner";
import BrandsSection from "@/components/home/BrandsSection";
import TrustSection from "@/components/home/TrustSection";
import { getProducts } from "@/lib/getProducts";

type Product = {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  subcategory?: string;
  description?: string;
  stock?: number;
};

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default async function HomePage() {
  const allProducts: Product[] = await getProducts();

  const featuredProducts = [...allProducts]
    .sort((a, b) => Number(b.id) - Number(a.id))
    .slice(0, 8);

  return (
    <main>
      <TopBar />
      <Navbar />

      <Hero />
      <CategorySection />

      <ProductSection
        title="Featured Products"
        subtitle="Discover some of our selected products."
        products={featuredProducts}
      />

      <DealsBanner />
      <BrandsSection />
      <TrustSection />

      <Footer />
    </main>
  );
}