import Link from "next/link";
import ProductCard from "@/components/ui/ProductCard";
import SectionHeader from "@/components/ui/SectionHeader";

type Product = {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  stock?: number;
};

type ProductSectionProps = {
  title?: string;
  subtitle?: string;
  products?: Product[];
};

export default function ProductSection({
  title = "Featured Products",
  subtitle = "Discover some of our selected products.",
  products = [],
}: ProductSectionProps) {
  return (
    <section className="container-ph section-gap">
      <SectionHeader title={title} subtitle={subtitle} />

      {products.length === 0 ? (
        <div className="rounded-[24px] border border-[#ead9d1] bg-white p-10 text-center">
          <h3 className="text-2xl font-semibold">No featured products yet</h3>
          <p className="mt-3 text-neutral-600">
            Featured products will appear here when available.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.name}
              price={product.price}
              image={product.image}
              category={product.category}
              stock={product.stock}
            />
          ))}
        </div>
      )}

      <div className="mt-8 text-center">
        <Link
          href="/shop"
          className="inline-flex rounded-full border border-[#ead9d1] px-6 py-3 text-sm font-medium transition hover:bg-[#f8f3ef]"
        >
          View All Products
        </Link>
      </div>
    </section>
  );
}