"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("ph_admin_logged_in") === "true";

    if (!isLoggedIn && pathname.startsWith("/admin")) {
      router.replace("/login");
      return;
    }

    setChecked(true);
  }, [pathname, router]);

  if (!checked) {
    return (
      <main className="min-h-screen grid place-items-center text-lg font-medium">
        Checking access...
      </main>
    );
  }

  return <>{children}</>;
}